package AssociadosClubeNautico;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Marco
 */
<<<<<<< HEAD:PPROG_TP_1_TESTE/src/AssociadosClubeNautico/SocioJovem.java
public abstract class SocioJovem extends Associados{
    
=======
public class SociosAdultos {
    //Aqui o joão tb é um tótó
    //mas sou adulto...
>>>>>>> 8990c9f432ff9e888317e8b86e9ef3781a75ed7f:TP1/src/tp1/SociosAdultos.java
}
