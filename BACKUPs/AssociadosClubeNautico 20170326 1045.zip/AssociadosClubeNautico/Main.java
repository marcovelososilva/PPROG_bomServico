/*
 * ASSOCIADOS CLUBE NAUTICO, DISCIPLINA PPROG ANO 2017.
 * 
 */
package AssociadosClubeNautico;

/**
 *
 * @author Marco-115883 | Joao-1161313 (1NB)
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Associados[] listaSocios = new Associados[12];
        listaSocios[0]=new SocioAdulto();
        listaSocios[1]=new SocioMenor();
        listaSocios[2]=new SocioSenior();
        listaSocios[3]=new SocioAdulto();
        listaSocios[4]=new SocioMenor();
        listaSocios[5]=new SocioSenior();
        listaSocios[6]=new SocioAdulto();
        listaSocios[7]=new SocioMenor();
        listaSocios[8]=new SocioSenior();
        listaSocios[9]=new SocioAdulto();
        listaSocios[10]=new SocioMenor();
        listaSocios[11]=new SocioSenior();
        
        //LISTA ENCARREGADOS EDUCAÇÃO
        //CALCULAR MENSALIDADE
    }
    
}
